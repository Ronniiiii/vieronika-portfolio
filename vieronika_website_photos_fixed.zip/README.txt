Vieronika website — fixed for your current GitHub repository layout.

Your GitHub repository has index.html and all .jpeg photos directly in the root, so this version references photos without the images/ prefix.

Upload/replace index.html in your existing GitHub repository. Keep all .jpeg photo files in the repository root. Commit the change, then wait for GitHub Pages to redeploy.
