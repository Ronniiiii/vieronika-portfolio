Vieronika website for GitHub Pages

Upload index.html and the images folder together to the ROOT of your GitHub repository.
Keep the folder structure exactly as it is. The photos are included inside images/.
